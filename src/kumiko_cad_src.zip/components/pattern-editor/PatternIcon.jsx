import React from 'react'

// Placeholder pattern thumbnail — an empty square for now. Meant to eventually
// render something derived from the pattern's actual strips/joints (and any
// user modifications), but that renderer doesn't exist yet, so this is just a
// bordered blank square. Every place that shows a pattern (list view, icon
// view, recently-used) renders through this one component, so wiring up the
// real thumbnail later only means changing it here.
export default function PatternIcon({ pattern, size = 28 }) {
  return (
    <div
      aria-hidden="true"
      style={{
        width: size,
        height: size,
        flexShrink: 0,
        border: '1px solid #ced4da',
        borderRadius: 3,
        background: '#fff',
      }}
    />
  )
}
